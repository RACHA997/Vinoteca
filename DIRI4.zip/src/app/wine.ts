export interface Wine {


  nombre: string,
  uvas: string,
  pais: string,
  anyo: number,


}
