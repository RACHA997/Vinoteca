import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nuevovino',
  templateUrl: './nuevovino.component.html',
  styleUrls: ['./nuevovino.component.css']
})
export class NuevovinoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
